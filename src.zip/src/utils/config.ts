export const CONFIG = {
  RASGUARD_PHONE: '+62XXXXXXXXXXX',
  API_BASE: 'https://api.rasguard.yourdomain',
};
