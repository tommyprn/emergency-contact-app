// import {AppRegistry} from 'react-native';
import AppNavigator from './app/AppNavigator';
// import 'react-native-gesture-handler';
// import {name as appName} from '../app.json';

export default function App() {
  return <AppNavigator />;
}
